Prefab Paradise - Final merged bundle (trimmed)

Includes armor features: rate limiting, admin one-time token, CI reindex wiring.
See .env.sample for required secrets.
