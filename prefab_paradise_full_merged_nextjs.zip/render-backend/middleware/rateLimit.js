import rateLimit from 'express-rate-limit';
export const limiter = rateLimit({ windowMs: process.env.RATE_LIMIT_WINDOW_MS ? Number(process.env.RATE_LIMIT_WINDOW_MS) : 60000, max: process.env.RATE_LIMIT_MAX ? Number(process.env.RATE_LIMIT_MAX) : 60, standardHeaders:true, legacyHeaders:false, message:{ error: 'Too many requests, slow down' } });
