#!/usr/bin/env bash
set -euo pipefail
: "${RENDER_BACKEND_URL:?Set RENDER_BACKEND_URL}"
: "${ADMIN_ONE_TIME_TOKEN:?Set ADMIN_ONE_TIME_TOKEN}"
curl -sS -X POST "$RENDER_BACKEND_URL/semantic/reindex" -H "X-Admin-Token: $ADMIN_ONE_TIME_TOKEN" -H "Content-Type: application/json"
echo
