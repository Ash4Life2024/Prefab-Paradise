import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import { limiter } from './middleware/rateLimit.js';
import { adminOneTimeAuth } from './middleware/adminAuth.js';
import { requireInternalToken } from './middleware/internalAuth.js';
import admin from 'firebase-admin';
import { Configuration, OpenAIApi } from 'openai';

if(process.env.FIREBASE_SERVICE_ACCOUNT_KEY){ try{ const svc = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY); admin.initializeApp({ credential: admin.credential.cert(svc) }); }catch(e){ console.warn('Invalid FIREBASE_SERVICE_ACCOUNT_KEY'); } }
const db = admin.firestore ? admin.firestore() : null;
const app = express();
app.use(cors());
app.use(express.json({limit:'2mb'}));
app.use(limiter);
app.get('/health', (req,res)=> res.json({ok:true}));
app.post('/crawl/state/:code', requireInternalToken, async (req,res)=>{ const code=(req.params.code||'').toUpperCase(); try{ let items=[]; if(code==='CA') items=[{id:'ca-adu-grant',title:'California ADU Grant',type:'grant',agency:'CalHFA',states:['CA'],eligibility_tags:['adu','first_time_buyer'],amount_range:'Up to $40,000',max_amount:40000,url:'https://www.calhfa.ca.gov/adu/',fullText:'ADU program.'}]; else if(code==='TX') items=[{id:'tx-rural-rehab-grant',title:'Texas Rural Rehab Grant',type:'grant',agency:'TDHCA',states:['TX'],eligibility_tags:['rural','low_income'],amount_range:'$3k-$10k',max_amount:10000,url:'https://www.tdhca.state.tx.us/',fullText:'Texas rural program.'}]; if(db){ const batch = db.batch(); items.forEach(p=> batch.set(db.collection('financePrograms').doc(p.id), {...p, lastUpdated: admin.firestore.FieldValue.serverTimestamp()}, {merge:true})); await batch.commit(); } res.json({success:true,count:items.length}); }catch(e){ console.error(e); res.status(500).json({error:e.message}); } });

app.post('/semantic/reindex', adminOneTimeAuth, async (req,res)=>{ try{ if(!db) return res.status(500).json({error:'firebase not configured'}); const snap = await db.collection('financePrograms').get(); const items=[]; snap.forEach(doc=> items.push({id:doc.id, ...doc.data()})); const configuration = new Configuration({ apiKey: process.env.OPENAI_API_KEY }); const openai = new OpenAIApi(configuration); const texts = items.map(i=> (i.title + '\n' + (i.fullText||'')).slice(0,2000)); const embeds=[]; for(let i=0;i<texts.length;i+=50){ const batch = texts.slice(i,i+50); const resp = await openai.createEmbedding({ model: process.env.EMBED_MODEL || 'text-embedding-3-small', input: batch }); resp.data.data.forEach(d=> embeds.push(d.embedding)); }
    if(process.env.VECTOR_PROVIDER === 'pinecone' && process.env.PINECONE_API_KEY && process.env.PINECONE_INDEX){ const pineconeUrl = `https://${process.env.PINECONE_INDEX}-${process.env.PINECONE_REGION || 'us-east-1'}.svc.pinecone.io/vectors/upsert`; const vectors = items.map((it,idx)=> ({ id: it.id, values: embeds[idx], metadata: { title: it.title, type: it.type } })); await fetch(pineconeUrl, { method:'POST', headers:{ 'Content-Type':'application/json', 'Api-Key': process.env.PINECONE_API_KEY }, body: JSON.stringify({ vectors }) }); }
    else { const batch = db.batch(); items.forEach((it,idx)=> batch.set(db.collection('financePrograms').doc(it.id), { embedding: embeds[idx] }, { merge:true })); await batch.commit(); }
    res.json({success:true,count: items.length}); }catch(e){ console.error(e); res.status(500).json({error:e.message}); } });

app.post('/semantic/search', async (req,res)=>{ try{ const { query, topK=10, state } = req.body || {}; if(!query) return res.status(400).json({error:'query required'}); if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:'no openai key'}); const configuration = new Configuration({ apiKey: process.env.OPENAI_API_KEY }); const openai = new OpenAIApi(configuration); const resp = await openai.createEmbedding({ model: process.env.EMBED_MODEL || 'text-embedding-3-small', input: query }); const qVec = resp.data.data[0].embedding; if(process.env.VECTOR_PROVIDER === 'pinecone' && process.env.PINECONE_API_KEY && process.env.PINECONE_INDEX){ const pineconeQueryUrl = `https://${process.env.PINECONE_INDEX}-${process.env.PINECONE_REGION || 'us-east-1'}.svc.pinecone.io/query`; const body = { topK, includeMetadata: true, vector: qVec }; if(state) body.filter = { state: { '$eq': state } }; const r = await fetch(pineconeQueryUrl, { method:'POST', headers: { 'Content-Type':'application/json', 'Api-Key': process.env.PINECONE_API_KEY }, body: JSON.stringify(body) }); const jr = await r.json(); const matches = jr.matches || []; const out=[]; for(const m of matches){ const doc = await db.collection('financePrograms').doc(m.id).get(); if(doc.exists) out.push({ id: doc.id, ...doc.data(), matchScore: m.score }); } return res.json({results: out}); }
    const snap = await db.collection('financePrograms').get(); const results=[]; snap.forEach(doc=>{ const d=doc.data(); let score=0; const text=(d.title + ' ' + (d.fullText||'')).toLowerCase(); if(text.includes(query.toLowerCase())) score+=50; if(state && (d.states||[]).includes(state)) score+=20; if(score>0) results.push({ id: doc.id, ...d, matchScore: score }); }); results.sort((a,b)=>b.matchScore - a.matchScore); res.json({results: results.slice(0,50)});
 }catch(e){ console.error(e); res.status(500).json({error:e.message}); } });

const PORT = process.env.PORT || 8080; app.listen(PORT, ()=> console.log('Listening on', PORT));
