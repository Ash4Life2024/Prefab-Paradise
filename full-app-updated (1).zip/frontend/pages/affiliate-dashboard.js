
import { useEffect, useState } from 'react';
import useAuth from '../utils/useAuth';
import { db } from '../utils/firebaseClient';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';

export default function AffiliateDashboard(){
  const user = useAuth();
  const [affiliate,setAffiliate]=useState(null);
  const [refs,setRefs]=useState([]);
  const [loading,setLoading]=useState(false);

  useEffect(()=>{
    if(!user) return;
    (async ()=>{
      setLoading(true);
      try{
        const q = query(collection(db,'affiliates'), where('email','==', user.email), orderBy('createdAt','desc'));
        const snap = await getDocs(q);
        if(!snap.empty){
          const data = snap.docs[0].data();
          setAffiliate(data);
          const rQ = query(collection(db,'affiliateReferrals'), where('affiliateId','==', data.affiliateId), orderBy('createdAt','desc'));
          const rSnap = await getDocs(rQ);
          setRefs(rSnap.docs.map(d=>({ id: d.id, ...d.data() })));
        }
      }catch(e){ console.error(e) }finally{ setLoading(false) }
    })();
  },[user]);

  if(!user) return <div className="container card">Please login to view dashboard.</div>;
  if(loading) return <div className="container card">Loading…</div>;
  if(!affiliate) return <div className="container card">No affiliate record found — apply <a href="/affiliate-apply">here</a>.</div>;

  const total = refs.reduce((s,r)=> s + (Number(r.amount || 0)), 0);
  return (
    <div className="container">
      <div className="card">
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div>
            <h2>Affiliate Dashboard</h2>
            <div className="small">ID: {affiliate.affiliateId} · Joined: {new Date(affiliate.createdAt?.seconds ? affiliate.createdAt.seconds*1000 : affiliate.createdAt || Date.now()).toLocaleDateString()}</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div className="metric"><div className="value">${(total||0).toFixed(2)}</div><div className="small">Total commissions</div></div>
            <div style={{marginTop:8}}><button className="btn">Request Payout</button></div>
          </div>
        </div>
      </div>

      <div style={{height:12}} />

      <div className="card">
        <h3>Recent referrals</h3>
        {refs.length===0 && <div>No referrals yet — share your link: <code>{location.origin}/?ref={affiliate.affiliateId}</code></div>}
        {refs.length>0 && <table className="table"><thead><tr><th>Name</th><th>Email</th><th>Product</th><th>Amount</th><th>Status</th></tr></thead><tbody>{refs.map(r=>(<tr key={r.id}><td>{r.name||'—'}</td><td>{r.email||'—'}</td><td>{r.product||'—'}</td><td>${r.amount||0}</td><td>{r.status||'pending'}</td></tr>))}</tbody></table>}
      </div>
    </div>
  )
}
