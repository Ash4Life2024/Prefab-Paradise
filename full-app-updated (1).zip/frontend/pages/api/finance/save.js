
import admin from '../../utils/adminClient';
import { getAuth } from 'firebase-admin/auth';
export default async function handler(req,res){
  if(req.method !== 'POST') return res.status(405).end();
  try{
    const { authorization } = req.headers;
    if(!authorization) return res.status(401).json({error:'Missing auth'});
    const token = authorization.replace('Bearer ','').trim();
    const auth = getAuth();
    const decoded = await auth.verifyIdToken(token);
    const { programId } = req.body;
    if(!programId) return res.status(400).json({error:'programId required'});
    await admin.collection('userFinanceApplications').add({ userId: decoded.uid, programId, status: 'saved', createdAt: new Date() });
    res.json({success:true});
  }catch(e){ console.error(e); res.status(500).json({error:e.message}); }
}
