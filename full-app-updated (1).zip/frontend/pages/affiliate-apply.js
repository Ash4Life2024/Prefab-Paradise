
import { useState } from 'react';
export default function AffiliateApply(){
  const [form,setForm]=useState({name:'',email:'',website:'',channels:'',notes:''});
  const [status,setStatus]=useState(null);
  const [errors,setErrors]=useState({});
  function validate(){
    const e={};
    if(!form.name) e.name='Name required';
    if(!form.email || !form.email.includes('@')) e.email='Valid email required';
    return e;
  }
  async function submit(){
    const e = validate(); setErrors(e);
    if(Object.keys(e).length) return;
    setStatus('loading');
    try{
      const r = await fetch('/api/affiliate/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)});
      const j = await r.json();
      if(j.success) setStatus('submitted'); else setStatus('error');
    }catch(err){ setStatus('error'); }
  }
  return (
    <div className="container">
      <div className="card">
        <h2>Affiliate Application</h2>
        <p className="small">Tell us about you — we fast-track reputable partners.</p>
        <div style={{marginTop:12}}>
          <label className="small">Full name</label>
          <input className="input" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
          {errors.name && <div style={{color:'var(--danger)'}}>{errors.name}</div>}
          <label className="small" style={{marginTop:8}}>Email</label>
          <input className="input" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
          {errors.email && <div style={{color:'var(--danger)'}}>{errors.email}</div>}
          <label className="small" style={{marginTop:8}}>Website / Social</label>
          <input className="input" value={form.website} onChange={e=>setForm({...form,website:e.target.value})} />
          <label className="small" style={{marginTop:8}}>Primary channels</label>
          <input className="input" value={form.channels} onChange={e=>setForm({...form,channels:e.target.value})} />
          <label className="small" style={{marginTop:8}}>Notes</label>
          <textarea className="input" rows={4} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} />
          <div style={{marginTop:12}}>
            <button className="btn" onClick={submit} disabled={status==='loading'}>{status==='loading' ? 'Submitting...' : 'Submit Application'}</button>
            {status==='submitted' && <span style={{marginLeft:12,color:'var(--success)'}}>Application submitted — check email.</span>}
            {status==='error' && <span style={{marginLeft:12,color:'var(--danger)'}}>Submission failed — try again.</span>}
          </div>
        </div>
      </div>
    </div>
  )
}
