
import { useState, useEffect, useRef } from 'react';
import useAuth from '../utils/useAuth';

export default function FinanceFinder(){
  const [q,setQ]=useState('');
  const [results,setResults]=useState([]);
  const [loading,setLoading]=useState(false);
  const [stateCode,setStateCode]=useState('');
  const user = useAuth();
  const timer = useRef(null);

  useEffect(()=>{ return ()=>{ if(timer.current) clearTimeout(timer.current); } },[]);

  function debounceSearch(val){
    if(timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(()=> doSearch(val), 400);
  }

  async function doSearch(val){
    setLoading(true);
    try{
      const r = await fetch('/api/finance/semantic',{method:'POST',headers:{'Content-Type':'application/json'},body: JSON.stringify({query: val, state: stateCode, topK:30})});
      const j = await r.json();
      setResults(j.results || []);
    }catch(e){ console.error(e); }
    setLoading(false);
  }

  function onChange(e){ setQ(e.target.value); debounceSearch(e.target.value); }
  async function saveProgram(id){
    if(!user){ alert('Login required'); return; }
    const token = await user.getIdToken();
    const r = await fetch('/api/finance/save',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body: JSON.stringify({programId: id})});
    const j = await r.json();
    if(j.success) alert('Saved'); else alert('Failed to save');
  }

  return (
    <div className="container">
      <div className="card">
        <h2>Finance Finder</h2>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <input className="input" placeholder="search grants, loans..." value={q} onChange={onChange} style={{flex:1}} />
          <input className="input" placeholder="State (CA)" value={stateCode} onChange={e=>setStateCode(e.target.value.toUpperCase())} style={{width:120}} />
          <button className="btn" onClick={()=>doSearch(q)}>Search</button>
        </div>
      </div>

      <div style={{height:12}}/>

      <div className="card">
        {loading && <div>Searching…</div>}
        {results.map(r => (
          <div key={r.id} style={{borderBottom:'1px solid #f1f5f9', padding:'12px 0'}}>
            <div style={{display:'flex',justifyContent:'space-between'}}>
              <div>
                <div style={{fontWeight:700}}>{r.title || r.name}</div>
                <div className="small">{r.agency} · {r.amount_range}</div>
                <div style={{marginTop:6}}>{(r.fullText || '').slice(0,200)}{(r.fullText||'').length>200 ? '…' : ''}</div>
              </div>
              <div style={{textAlign:'right'}}>
                <a href={r.url} target="_blank" rel="noreferrer" className="btn secondary">View</a>
                <div style={{height:8}}/>
                <button className="btn" onClick={()=>saveProgram(r.id)}>Save</button>
              </div>
            </div>
          </div>
        ))}
        {results.length===0 && !loading && <div style={{padding:12,color:'var(--muted)'}}>No results — try a broader query like "first time homebuyer grant".</div>}
      </div>
    </div>
  )
}
