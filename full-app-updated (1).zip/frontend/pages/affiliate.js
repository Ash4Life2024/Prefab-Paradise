
import Link from 'next/link';
export default function AffiliateLanding(){
  return (
    <div className="container">
      <div className="header">
        <h1>Affiliate Program — Prefab Paradise</h1>
        <div><Link href="/"><a>Home</a></Link></div>
      </div>

      <div className="card">
        <h2>Join our trusted affiliate network</h2>
        <p className="small">High-ticket conversions · Warranty-backed suppliers · Fast onboarding</p>
        <div style={{display:'flex',gap:12,marginTop:12}}>
          <Link href="/affiliate-apply"><button className="btn">Apply as Affiliate</button></Link>
          <Link href="/affiliate-dashboard"><button className="btn secondary">Affiliate Dashboard</button></Link>
        </div>
      </div>

      <div style={{height:18}} />

      <div className="card">
        <h3>How it works</h3>
        <ol>
          <li>Apply & get verified within 48 hours.</li>
          <li>Receive affiliate links, creatives, and real-time tracking.</li>
          <li>Earn tiered commissions and automatic payouts.</li>
        </ol>
      </div>
      <div className="footer">Sponsored by Informative-Insight · Built with NovaBoo energy ✨</div>
    </div>
  )
}
