
import admin from 'firebase-admin';
if(!admin.apps.length){
  const svc = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY || '{}');
  admin.initializeApp({ credential: admin.credential.cert(svc) });
}
export default admin.firestore();
