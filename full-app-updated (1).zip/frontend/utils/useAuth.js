
import { useEffect, useState } from 'react';
import { auth } from './firebaseClient';
export default function useAuth(){ const [u,setU]=useState(null); useEffect(()=>{ const off = auth.onAuthStateChanged(a=>setU(a)); return off; },[]); return u; }
