Prefab Paradise updated frontend UI bundle. Run frontend with `cd frontend && npm install && npm run dev`.
