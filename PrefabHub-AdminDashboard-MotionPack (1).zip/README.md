# JarvisHub Admin Dashboard Motion Graphics Pack

This pack includes placeholder motion graphics overlays for the 60-second demo trailer.

## Folders
- **Arrows/**: GitHub → Render/Vercel arrows
- **Exports/**: CSV/PDF download animations
- **Charts/**: Chart highlight overlays
- **Particles/**: Intro & closing shimmer effects
- **Tooltips/**: Chart & table tooltips
- **TextOverlays/**: Animated text captions (.mogrt)

Use these placeholders to replace with real .mov/.mogrt files when creating the trailer.
