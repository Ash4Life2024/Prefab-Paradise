
const functions = require('firebase-functions');
const admin = require('firebase-admin');
const sgMail = require('@sendgrid/mail');

if(!admin.apps.length) admin.initializeApp();
const db = admin.firestore();
sgMail.setApiKey(process.env.SENDGRID_API_KEY || functions.config().sendgrid?.key || '');

exports.handleAffiliateApplication = functions.https.onRequest(async (req,res)=>{
  try{
    const app = req.body;
    const id = app.id;
    // mark received
    await db.collection('affiliateApplications').doc(id).set({...app, status:'received', receivedAt: admin.firestore.FieldValue.serverTimestamp()}, {merge:true});

    // basic auto-accept logic placeholder (can be expanded)
    let autoAccept = false;
    if(app.website && app.website.includes('trustedpartner.com')) autoAccept = true;

    if(autoAccept){
      const affRef = await db.collection('affiliates').add({
        name: app.name, email: app.email, website: app.website, createdAt: admin.firestore.FieldValue.serverTimestamp(), payouts: {method:'stripe', balance:0}
      });
      await db.collection('affiliateApplications').doc(id).update({status:'approved', approvedAt: admin.firestore.FieldValue.serverTimestamp(), affiliateId: affRef.id});
      // send welcome email
      if(sgMail) await sgMail.send({to: app.email, from:'hello@informative-insight.com', subject:'Affiliate Approved', text:`Welcome! Your affiliate id: ${affRef.id}`});
    } else {
      // send receipt email to applicant
      if(sgMail) await sgMail.send({to: app.email, from:'hello@informative-insight.com', subject:'Application Received', text:`Thanks ${app.name}, we'll review your application.`});
    }

    // notify internal team
    if(sgMail) await sgMail.send({to:'team@informative-insight.com', from:'no-reply@informative-insight.com', subject:`New Affiliate App: ${app.name}`, text: JSON.stringify(app, null, 2)});

    return res.json({success:true});
  }catch(e){
    console.error(e);
    return res.status(500).json({error:e.message});
  }
});
