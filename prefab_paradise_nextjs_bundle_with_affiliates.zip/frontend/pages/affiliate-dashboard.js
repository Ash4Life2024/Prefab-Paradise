
import { useEffect, useState } from 'react';
import { db } from '../utils/firebaseClient';
import { collection, query, where, getDocs } from 'firebase/firestore';
import useAuth from '../utils/useAuth';

export default function AffiliateDashboard(){
  const user = useAuth();
  const [data, setData] = useState(null);

  useEffect(()=> {
    if(!user) return;
    (async ()=>{
      const q = query(collection(db,'affiliates'), where('email','==', user.email));
      const snap = await getDocs(q);
      if(!snap.empty) setData(snap.docs[0].data());
    })();
  },[user]);

  if(!user) return <div>Please login</div>;
  if(!data) return <div>Loading...</div>;

  return (
    <div style={{padding:20}}>
      <h2>Affiliate Dashboard</h2>
      <div>Affiliate ID: {data.affiliateId}</div>
      <div>Balance: ${data.payouts?.balance || 0}</div>
      <div><a href={`/affiliate/ref/${data.affiliateId}`}>Your Affiliate Link</a></div>
    </div>
  )
}
