
import admin from '../../../utils/adminClient';

export default async function handler(req,res){
  const { ref, dest } = req.query;
  try{
    await admin.collection('affiliateClicks').add({
      affiliateId: ref || 'unknown',
      dest,
      utm: req.query.utm_source || null,
      ts: new Date(),
      userAgent: req.headers['user-agent'] || null
    });
    // basic redirect
    return res.redirect(dest || '/');
  }catch(e){
    console.error(e);
    return res.status(500).send('error');
  }
}
