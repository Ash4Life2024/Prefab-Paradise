
import admin from '../../../utils/adminClient';

export default async function handler(req,res){
  if(req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
  const data = req.body;
  try{
    const docRef = await admin.collection('affiliateApplications').add({
      ...data,
      status: 'pending',
      createdAt: new Date()
    });
    // trigger onboarding function via webhook if set
    if(process.env.INTERNAL_AFFILIATE_WEBHOOK){
      fetch(process.env.INTERNAL_AFFILIATE_WEBHOOK, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id: docRef.id, ...data})}).catch(()=>{});
    }
    return res.json({success:true, id: docRef.id});
  }catch(err){
    console.error(err);
    return res.status(500).json({success:false,error:err.message});
  }
}
