
import { useState } from 'react';

export default function AffiliateApply(){
  const [form, setForm] = useState({name:'',email:'',company:'',website:'',channels:'',notes:''});
  const [status, setStatus] = useState(null);

  const handle = (k,v)=> setForm(s=>({...s,[k]:v}));

  const submit = async () => {
    setStatus('loading');
    try{
      const res = await fetch('/api/affiliate/apply', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(form)
      });
      const json = await res.json();
      if(json.success) setStatus('submitted');
      else setStatus('error:'+json.error);
    }catch(e){ setStatus('error:'+e.message) }
  };

  return (
    <div style={{padding:24}}>
      <h1>Partner with Prefab Paradise</h1>
      <p>Join our curated affiliate network for prefab homes.</p>

      <label>Name</label><br/>
      <input onChange={e=>handle('name',e.target.value)} /><br/>
      <label>Email</label><br/>
      <input onChange={e=>handle('email',e.target.value)} /><br/>
      <label>Company</label><br/>
      <input onChange={e=>handle('company',e.target.value)} /><br/>
      <label>Website / Profile</label><br/>
      <input onChange={e=>handle('website',e.target.value)} /><br/>
      <label>Channels (eg. IG, YouTube)</label><br/>
      <input onChange={e=>handle('channels',e.target.value)} /><br/>
      <label>Notes</label><br/>
      <textarea onChange={e=>handle('notes',e.target.value)} /><br/>

      <button onClick={submit} disabled={status==='loading'}>Apply as Affiliate</button>

      {status && <div style={{marginTop:12}}>{status}</div>}
    </div>
  )
}
