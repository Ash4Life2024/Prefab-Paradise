
import Link from 'next/link';

export default function AffiliateLanding(){
  return (
    <div style={{padding:24}}>
      <h1>Prefab Paradise Affiliate Program</h1>
      <p>Earn commissions promoting prefab, container & tiny homes. We handle logistics, warranty verification, and provide tracking + payouts.</p>

      <h3>Why partner with us?</h3>
      <ul>
        <li>High-ticket conversions & tiered commissions</li>
        <li>Verified sellers + warranty protection</li>
        <li>Automated tracking, payouts & reporting</li>
        <li>AI-powered match recommendations to boost conversions</li>
      </ul>

      <h3>How it works</h3>
      <ol>
        <li>Apply → quick review</li>
        <li>Get an affiliate link + dashboard access</li>
        <li>Drive traffic → Earn payouts</li>
      </ol>

      <Link href="/affiliate-apply"><button>Apply Now</button></Link>
    </div>
  )
}
