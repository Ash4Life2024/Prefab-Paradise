
export async function callDreamBuild(address){
  const res = await fetch('/api/dream-build', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({address})});
  return res.json();
}
