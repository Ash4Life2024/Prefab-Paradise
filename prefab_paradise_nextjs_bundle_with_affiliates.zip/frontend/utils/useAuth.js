
import { useEffect, useState } from 'react';
import { auth } from './firebaseClient';

export default function useAuth(){
  const [user, setUser] = useState(null);
  useEffect(()=>{
    const unsub = auth.onAuthStateChanged(u=>setUser(u));
    return unsub;
  },[]);
  return user;
}
