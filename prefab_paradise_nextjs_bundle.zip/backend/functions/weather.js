
const functions = require('firebase-functions');
exports.simulateWeather = functions.https.onRequest(async (req, res) => {
  const { lat, lng } = req.body;
  res.json({ success: true, message: 'weather simulated (stub)', lat, lng });
});
