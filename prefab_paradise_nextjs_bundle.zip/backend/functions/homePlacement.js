
const functions = require('firebase-functions');
exports.placeHome = functions.https.onRequest(async (req, res) => {
  const { modelId, siteId } = req.body;
  res.json({ success: true, message: 'home placement created (stub)', modelId, siteId });
});
