# Prefab Paradise

Next.js + Firebase + Render scaffold.