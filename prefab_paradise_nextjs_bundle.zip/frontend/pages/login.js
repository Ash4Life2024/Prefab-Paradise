
import { useState } from 'react';
import { signIn } from '../utils/firebaseClient';

export default function Login(){
  const [email,setEmail]=useState(''); const [pw,setPw]=useState('');
  const submit = async ()=> {
    try{
      await signIn(email,pw);
      alert('Logged in');
    }catch(e){ alert(e.message) }
  }
  return (
    <div style={{padding:20}}>
      <h2>Login</h2>
      <input placeholder='Email' onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder='Password' type='password' onChange={e=>setPw(e.target.value)} /><br/>
      <button onClick={submit}>Login</button>
    </div>
  )
}
