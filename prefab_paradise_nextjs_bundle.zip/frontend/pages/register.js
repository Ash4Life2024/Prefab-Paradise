
import { useState } from 'react';
import { createUser } from '../utils/firebaseClient';

export default function Register(){
  const [email,setEmail]=useState(''); const [pw,setPw]=useState('');
  const submit = async ()=> {
    try{
      await createUser(email,pw);
      alert('Registered');
    }catch(e){ alert(e.message) }
  }
  return (
    <div style={{padding:20}}>
      <h2>Register</h2>
      <input placeholder='Email' onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder='Password' type='password' onChange={e=>setPw(e.target.value)} /><br/>
      <button onClick={submit}>Create Account</button>
    </div>
  )
}
