
export default function Dashboard(){
  return (
    <div style={{padding:20}}>
      <h2>Seller / Buyer Dashboard (stub)</h2>
      <p>Here you will see orders, listings, and Dream Build sessions.</p>
    </div>
  )
}
