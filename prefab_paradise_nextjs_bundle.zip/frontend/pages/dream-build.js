
import { useState } from 'react';
import { callDreamBuild } from '../utils/backendClient';

export default function DreamBuild(){
  const [address,setAddress]=useState('');
  const runPreview = async ()=> {
    const res = await callDreamBuild(address);
    alert(JSON.stringify(res));
  }
  return (
    <div style={{padding:20}}>
      <h2>Dream Build Engine™ (Preview)</h2>
      <p>Enter an address or drop a pin to begin satellite preview + placement</p>
      <input placeholder='Address or lat,long' value={address} onChange={e=>setAddress(e.target.value)} style={{width:'80%'}}/>
      <button onClick={runPreview}>Preview Site</button>
      <div id='previewCanvas' style={{marginTop:20, height:400, border:'1px solid #ccc'}}>3D/AR Viewer placeholder</div>
    </div>
  )
}
